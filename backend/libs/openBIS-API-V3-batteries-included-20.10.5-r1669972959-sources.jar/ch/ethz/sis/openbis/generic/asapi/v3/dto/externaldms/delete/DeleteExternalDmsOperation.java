/*
 * Copyright 2014 ETH Zuerich, CISD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ch.ethz.sis.openbis.generic.asapi.v3.dto.externaldms.delete;

import java.util.List;

import ch.ethz.sis.openbis.generic.asapi.v3.dto.common.delete.DeleteObjectsOperation;
import ch.ethz.sis.openbis.generic.asapi.v3.dto.externaldms.id.IExternalDmsId;
import ch.systemsx.cisd.base.annotation.JsonObject;

@JsonObject("as.dto.externaldms.delete.DeleteExternalDmsOperation")
public class DeleteExternalDmsOperation extends DeleteObjectsOperation<IExternalDmsId, ExternalDmsDeletionOptions>
{
    private static final long serialVersionUID = 1L;

    @SuppressWarnings("unused")
    private DeleteExternalDmsOperation()
    {
    }

    public DeleteExternalDmsOperation(List<? extends IExternalDmsId> objectIds, ExternalDmsDeletionOptions options)
    {
        super(objectIds, options);
    }

}
