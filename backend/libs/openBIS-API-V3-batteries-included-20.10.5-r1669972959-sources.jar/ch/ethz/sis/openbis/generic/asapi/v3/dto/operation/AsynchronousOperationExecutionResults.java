/*
 * Copyright 2015 ETH Zuerich, CISD
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ch.ethz.sis.openbis.generic.asapi.v3.dto.operation;

import ch.ethz.sis.openbis.generic.asapi.v3.dto.common.ObjectToString;
import ch.ethz.sis.openbis.generic.asapi.v3.dto.operation.id.OperationExecutionPermId;
import ch.systemsx.cisd.base.annotation.JsonObject;

/**
 * @author pkupczyk
 */
@JsonObject("as.dto.operation.AsynchronousOperationExecutionResults")
public class AsynchronousOperationExecutionResults implements IOperationExecutionResults
{

    private static final long serialVersionUID = 1L;

    private OperationExecutionPermId executionId;

    @SuppressWarnings("unused")
    private AsynchronousOperationExecutionResults()
    {
    }

    public AsynchronousOperationExecutionResults(OperationExecutionPermId executionId)
    {
        this.executionId = executionId;
    }

    public OperationExecutionPermId getExecutionId()
    {
        return executionId;
    }

    @Override
    public String toString()
    {
        return new ObjectToString(this).append("executionId", executionId).toString();
    }

}
